from django.contrib import admin
from Rest_Farmington.models import Rest_Farmington_Hills

# Register your models here.
admin.site.register(Rest_Farmington_Hills)